# DiZone 💎 UAVS in the Semi-final Round: Demo MVP Startup's Flow & algorithm - Stage 01

This is the application version in the first phase of the **DiZone - UAVS project**, which is best discovering startup platform for all investors, newbie startups and viewers to connect together. 

+ See more of our impressive App Prototype [here via Figma](https://www.figma.com/proto/tWVRd1SeHWYD7mZmpATL0E/DiZone?node-id=199%3A6728&scaling=min-zoom&page-id=193%3A5273&starting-point-node-id=199%3A6737&show-proto-sidebar=1)
+ Want to know more about our algorithm behind that eye-catching rendering? Watch it at above at folder **./my-algorithm** or [this Github](https://github.com/louishoang101/DiZone_SF_UH21)

```rb
git clone https://github.com/dinhtrivonguyen/DiZone_SF_UH21.git (dev)
cd my-algorithm
```

## Watch a demo about MVP Startup's Flow

[![Watch a demo: DiZone Demo App - Stage 01](https://i.ytimg.com/vi/yFH9PPpJUyQ/hqdefault.jpg)](https://youtu.be/yFH9PPpJUyQ "Watch a demo: DiZone Demo App - Stage 01")

## Addition

In addition, in this project, we tried to retrieve the most useful trend results for startups and investors from PowerBi through DiZone's automatic data update algorithm.
See more at folder **./power-bi-react-webview** or see [here via Github project](https://github.com/dinhtrivonguyen/PowerPi-React-Demo)

```rb
cd power-bi-react-webview
```

![alt text](screenshots/report.png)

## Talk about algorithms!

DiZone has researched and in the process applied 2 algorithms to optimize and process data through **Count Vectorization** and **Suggestions, also known as a NLP recommendation engine using unsupervised learning**.

+ You can check out DiZone's demo algorithm how to use count vectorization on real text data at folder **./my-algorithm** or see [here via Colab Google](https://colab.research.google.com/drive/1w5HJtIFZfHGU6M7HJloliaOVsrppNwGV?usp=sharing)

+ **Highly appreciated**: And the way DiZone impressively demonstrates the feature of suggesting suitable objects according to the needs and personalization of the interests of startup users and investors, helping to increase the accessibility of the list of potential audiences. 
See more at folder **./my-algorithm** or see at the [Colab project](https://colab.research.google.com/drive/1vXEwisevoFNrEDOsStT9SycykG3th3lv?usp=sharing)

```rb
cd my-algorithm
```

## To-do in Stage 2

  - [ ] Use Firebase to sign up, sign in to your account
  - [ ] Complete Investor's Flow with the same version, allowing video uploads
  - [ ] Allow algorithm & datasets to work well on the app
  - [ ] Linking digital wallet for payment

## License

MIT


