import React, { Component, useRef, useState } from "react";
import { SafeAreaView, FlatList, Text, Image, View, Dimensions, StyleSheet, TouchableOpacity, Button } from "react-native";

import Icon from "react-native-vector-icons/FontAwesome"; // chưa import icon vào đc

import Carousel from "react-native-snap-carousel"; // Version can be specified in package.json

import { scrollInterpolator, animatedStyles } from "@/utils/animations";
import { useTheme } from "@react-navigation/native";

const SLIDER_WIDTH = Dimensions.get("window").width;
const ITEM_WIDTH = Math.round(SLIDER_WIDTH * 0.8);
const ITEM_HEIGHT = Math.round((ITEM_WIDTH * 9) / 5);

const DATA = [
  {
    id: "01",
    title: "Investor",
    image: require("@/assets/investor-icon.png")
  },
  {
    id: "02",
    title: "Startup",
    image: require("@/assets/startup-icon.png")
  },
  {
    id: "03",
    title: "Viewer",
    image: require("@/assets/viewer-icon.png")
  }
];

const Roles = ({ _, navigation }) => {
  const [index, setIndex] = useState(0);
  const { colors } = useTheme();
  const styles = makeStyles(colors);
  const ref = useRef(null);
  const _renderItem = ({ item, index }) => {
    return (
      <View style={styles.itemContainer}>
        <Image style={styles.image} source={item.image} />
        <Text style={styles.itemLabel}>{`You are ${item.title}?`}</Text>
      </View>
    );
  };
  return (
    <View flex={1} backgroundColor={colors.primary} justifyContent="center">
      <View>
        <Carousel
          ref={c => (ref.current = c)}
          data={DATA}
          renderItem={_renderItem}
          sliderWidth={SLIDER_WIDTH}
          itemWidth={ITEM_WIDTH}
          containerCustomStyle={styles.carouselContainer}
          inactiveSlideShift={0}
          onSnapToItem={index => setIndex(index)}
          scrollInterpolator={scrollInterpolator}
          slideInterpolatedStyle={animatedStyles}
          useScrollView={true}
        />
      </View>
      <Text style={styles.counter}>{index}</Text>
      <View>{}</View>
      <TouchableOpacity style={styles.button} onPress={() => navigation.navigate("ApplicationScreen")}>
        <Text style={styles.button_text}>Continue</Text>
        {/* <Icon name="facebook" backgroundColor="#3b5998" /> */}
      </TouchableOpacity>
    </View>
  );
};
export default Roles;
const makeStyles = colors =>
  StyleSheet.create({
    carouselContainer: {
      marginTop: 10
    },
    image: {
      width: ITEM_WIDTH - 20,
      height: ITEM_WIDTH - 20,
      borderRadius: 10
    },
    itemContainer: {
      // width: ITEM_WIDTH,
      // height: ITEM_HEIGHT,
      alignItems: "center",
      justifyContent: "center"
    },
    itemLabel: {
      color: "dodgerblue",
      fontSize: 30
    },
    counter: {
      fontSize: 30,
      fontWeight: "bold",
      textAlign: "center"
    },
    button: {
      backgroundColor: "white",
      paddingVertical: 10,
      marginHorizontal: 15,
      marginVertical: 20,
      borderRadius: 16,
      flexDirection: "row",
      justifyContent: "center",
      alignItems: "center"
    },
    button_text: {
      color: colors.primary
    }
  });
