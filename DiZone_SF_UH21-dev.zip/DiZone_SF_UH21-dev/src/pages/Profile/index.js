import { Typography } from "@/components";
import React from "react";
import { Image, ScrollView, StyleSheet, Text, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import Edit from "./Edit";
import Main from "./Main";

const index = ({ route, navigation }) => {
  console.log(route);
  return (
    <ScrollView>
      <SafeAreaView>
        <Typography variant="more" style={{ fontSize: 20, fontWeight: "bold", marginVertical: 20, marginLeft: 24 }}>
          Profile
        </Typography>
        <View alignItems="center">
          <Image source={require("@/assets/startup.jpg")} style={styles.avatar} />
          <Typography style={{ fontSize: 20, marginVertical: 5 }}>Campus Bubble</Typography>
          <Typography style={{ fontSize: 16, color: "#898989" }}>contact@campusbubble.com</Typography>
        </View>
        {
          {
            MainProfile: <Main />,
            EditProfile: <Edit />
          }[route.name]
        }
      </SafeAreaView>
    </ScrollView>
  );
};

export default index;

const styles = StyleSheet.create({
  avatar: {
    width: 150,
    height: 150,
    borderRadius: 100,
    marginBottom: 10
  }
});
