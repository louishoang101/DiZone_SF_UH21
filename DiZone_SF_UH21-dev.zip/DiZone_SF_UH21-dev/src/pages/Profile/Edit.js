import { Input } from "@/components/Form";
import { Item } from "@/containers";
import React from "react";
import { StyleSheet, Text, View } from "react-native";

const Edit = () => {
  return (
    <View marginVertical={20} paddingHorizontal={25}>
      <Input title="Business Name" defaultValue="Campus Bubble" />
      <Input title="Email" defaultValue="contact@campusbubble.com" />
      <Input title="Social URL" defaultValue="facebook.com/Campus Bubble" />
      {Array(2)
        .fill({
          icon: <View />,
          title: "My Details"
        })
        .map(({ icon, title }, index) => (
          <Item key={index} icon={icon} title={title} onPress={() => {}} />
        ))}
    </View>
  );
};

export default Edit;

const styles = StyleSheet.create({});
