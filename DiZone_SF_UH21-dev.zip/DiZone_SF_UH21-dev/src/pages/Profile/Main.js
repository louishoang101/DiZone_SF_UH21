import { ArrowRightIcon } from "@/assets/svg";
import { Button } from "@/components";
import { Item } from "@/containers";
import { useNavigation } from "@react-navigation/core";
import React from "react";
import { StyleSheet, Text, View } from "react-native";

const Main = () => {
  const navigation = useNavigation();
  return (
    <View>
      <View marginTop={20} borderTopWidth={1} borderTopColor="#E2E2E2">
        {Array(5)
          .fill({
            icon: <View />,
            title: "My Details"
          })
          .map(({ icon, title }, index) => (
            <Item key={index} icon={icon} title={title} onPress={() => navigation.navigate("EditProfile")} />
          ))}
      </View>
      <View alignItems="center">
        <Button title="LOG OUT" />
      </View>
    </View>
  );
};

export default Main;

const styles = StyleSheet.create({});
