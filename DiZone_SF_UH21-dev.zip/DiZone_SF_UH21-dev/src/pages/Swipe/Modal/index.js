import { Typography } from "@/components";
import { Fonts } from "@/navigation/Theme";
import React from "react";
import { Dimensions, Image, StyleSheet, Text, View } from "react-native";
import { pets } from "../data";

const { width } = Dimensions.get("window");

const Modal = () => {
  return (
    <View>
      <View style={styles.info}>
        <View>
          <Text style={Fonts.header}>Stephanie Campell</Text>
          <View flexDirection="row">
            <Text>F&B</Text>
            <Text>Community</Text>
          </View>
        </View>
        <Image source={pets[1].source} style={styles.avatar} />
      </View>
      <View style={[styles.item, { flexDirection: "row", alignItems: "center" }]}>
        <View flex={1}>
          <Typography variant="subtitle">OCUPATION</Typography>
          <Typography>Angel Investor</Typography>
        </View>
        <View flex={1} marginLeft={30}>
          <Typography variant="subtitle">OCUPATION</Typography>
          <Typography>Angel Investor</Typography>
        </View>
      </View>
      <View style={styles.item}>
        <Typography variant="subtitle">MY TYPE OF INVESTORS</Typography>
        <Typography style={{ marginVertical: 10 }}>I call myself a "professional mom to entrepreneur</Typography>
        <Typography variant="more">See more</Typography>
      </View>
      <View style={styles.item}>
        <Typography variant="subtitle">WHAT ARE YOU LOOKING FOR IN A STARTUP?</Typography>
        <Typography style={{ marginVertical: 10 }}>I look for founder passion and enthusiasm, </Typography>
        <Typography variant="more">See more</Typography>
      </View>
      <View style={styles.item}>
        <Typography variant="subtitle">WHAT ARE YOU LOOKING FOR IN A TEAM?</Typography>
        <Typography style={{ marginVertical: 10 }}>Founders should be passionate and hungry for</Typography>
        <Typography variant="more">See more</Typography>
      </View>
    </View>
  );
};

export default Modal;

const styles = StyleSheet.create({
  info: {
    marginTop: 15,
    marginBottom: 30,
    marginHorizontal: 10,
    padding: 18,
    backgroundColor: "#fff",
    borderRadius: 10,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center"
  },
  avatar: {
    width: width * 0.13,
    height: width * 0.13,
    borderRadius: 4
  },
  item: {
    marginBottom: 10,
    padding: 24,
    backgroundColor: "#fff",
    borderRadius: 10
  }
});
