export const pets = [
  {
    name: "Stephanie Campbell",
    company: "Houston Angel Network",
    source: require("@/assets/pet1.jpg")
  },
  {
    name: "Skip Walter",
    company: "Zillionaire",
    source: require("@/assets/pet2.jpg")
  },
  {
    name: "Ozan Isinak",
    company: "Keiretsu",
    source: require("@/assets/pet3.jpg")
  },
  {
    name: "Kevin O’Leary",
    company: "StartEngine",
    source: require("@/assets/pet4.jpg")
  },
  {
    name: "Alexis Ohanian",
    company: "NY Angel",
    source: require("@/assets/pet5.jpg")
  }
];
