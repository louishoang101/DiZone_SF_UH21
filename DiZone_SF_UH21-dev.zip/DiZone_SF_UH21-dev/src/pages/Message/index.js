import React from 'react';
import { View, Text, Button, StyleSheet, FlatList } from 'react-native';

import {
  Container,
  Card,
  UserInfo,
  UserImgWrapper,
  UserImg,
  UserInfoText,
  UserName,
  PostTime,
  MessageText,
  TextSection,
} from './styles';


const Messages = [
  {
    id: '1',
    userName: 'Jenny Doe',
    userImg: require('@/assets/user-2.jpg'),
    messageTime: '4 mins ago',
    messageText:
      'You: Thanks for sharing your opinion.',
  },
  {
    id: '2',
    userName: 'John Doe',
    userImg: require('@/assets/user-3.jpg'),
    messageTime: '2 hours ago',
    messageText:
      'You: I would like to hold a meeting... ',
  },
  {
    id: '3',
    userName: 'Ken William',
    userImg: require('@/assets/user-4.jpg'),
    messageTime: '1 hours ago',
    messageText:
      'You: Such a brilliant idea! Apprecia..',
  },
  {
    id: '4',
    userName: 'Selina Paul',
    userImg: require('@/assets/user-5.jpg'),
    messageTime: '1 day ago',
    messageText:
      'You: Please let me know if you nee.. .',
  },
  {
    id: '5',
    userName: 'Christy Alex',
    userImg: require('@/assets/user-6.jpg'),
    messageTime: '2 days ago',
    messageText:
      'You: Dear Christy, it’s such an honour..',
  },
];

const index = ({navigation}) => {
    return (
      <Container>
        <FlatList 
          data={Messages}
          keyExtractor={item=>item.id}
          renderItem={({item}) => (
            <Card onPress={() => navigation.navigate('Chat', {userName: item.userName})}>
              <UserInfo>
                <UserImgWrapper>
                  <UserImg source={item.userImg} />
                </UserImgWrapper>
                <TextSection>
                  <UserInfoText>
                    <UserName>{item.userName}</UserName>
                    <PostTime>{item.messageTime}</PostTime>
                  </UserInfoText>
                  <MessageText>{item.messageText}</MessageText>
                </TextSection>
              </UserInfo>
            </Card>
          )}
        />
      </Container>
    );
};

export default index;

const styles = StyleSheet.create({
  container: {
    flex: 1, 
    alignItems: 'center', 
    justifyContent: 'center'
  },
});
