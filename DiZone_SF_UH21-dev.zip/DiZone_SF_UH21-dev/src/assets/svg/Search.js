import * as React from "react";
import Svg, { Path } from "react-native-svg";

function SvgComponent(props) {
  return (
    <Svg width={32} height={32} fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
      <Path
        d="M20.667 18.667h-1.054l-.373-.36a8.628 8.628 0 002.093-5.64A8.666 8.666 0 0012.667 4 8.666 8.666 0 004 12.667a8.666 8.666 0 008.667 8.666c2.146 0 4.12-.786 5.64-2.093l.36.373v1.054l6.666 6.653 1.987-1.987-6.653-6.666zm-8 0c-3.32 0-6-2.68-6-6s2.68-6 6-6 6 2.68 6 6-2.68 6-6 6z"
        fill={props.focused ? "#FE3449" : "#99A3B0"}
      />
    </Svg>
  );
}

export default SvgComponent;
