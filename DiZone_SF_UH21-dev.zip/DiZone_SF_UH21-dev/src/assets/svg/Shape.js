import * as React from "react";
import Svg, { Path } from "react-native-svg";

function SvgComponent(props) {
  return (
    <Svg width={26} height={25} fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
      <Path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M16.44 21.844C16.44 23.587 14.9 25 13 25c-1.825 0-3.318-1.302-3.434-2.948l-.007-.208h6.882zM12.988 0c5.063 0 8.277 3.226 9.168 8.408l1.23 8.185C24.251 19.622 26 18.588 26 20.248c0 1.057-1.142 1.553-3.426 1.486l-.334-.013H3.76l-.334.014C1.142 21.8 0 21.305 0 20.248c0-1.602 1.626-.698 2.519-3.347l.096-.309s.955-6.168 1.23-8.185C4.713 3.358 7.786.167 12.627.006l.36-.006z"
        fill={props.focused ? "#FE3449" : "#99A3B0"}
      />
    </Svg>
  );
}

export default SvgComponent;
