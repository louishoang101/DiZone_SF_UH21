import * as React from "react";
import Svg, { Path, Circle } from "react-native-svg";

function SvgComponent(props) {
  return (
    <Svg width={29} height={31} fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
      <Path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M0 14.093C0 7.898 5.458 3 12 3s12 4.898 12 11.093c0 .398-.026.786-.068 1.165-.67 6.373-6.288 10.813-8.883 12.524L13.2 29v-3.939c-.141.014-.28.034-.418.053a5.52 5.52 0 01-.782.073c-6.542 0-12-4.899-12-11.094zm21.6 0c0-4.696-4.211-8.628-9.6-8.628-5.389 0-9.6 3.932-9.6 8.628 0 4.697 4.211 8.628 9.6 8.628.738 0 1.46-.082 2.163-.228l1.437-.299v1.864c2.457-2.02 5.531-5.12 5.946-9.064l.002-.005v-.005a7.92 7.92 0 00.052-.89z"
        fill={props.focused ? "#FE3449" : "#99A3B0"}
      />
      {/* <Circle cx={22.5} cy={6.5} r={6.5} fill="#FE3449" /> */}
    </Svg>
  );
}

export default SvgComponent;
