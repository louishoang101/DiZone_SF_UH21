import { DefaultTheme } from "@react-navigation/native";
import { StyleSheet } from "react-native";

export const Theme = {
  ...DefaultTheme,
  colors: {
    ...DefaultTheme.colors,
    primary: "#1C58F2"
  }
};

export const Fonts = StyleSheet.create({
  header: {
    fontSize: 21,
    fontWeight: "700",
    lineHeight: 22,
    letterSpacing: -0.11,
    color: "#4A4A4A"
  },
  title: {
    fontSize: 16,
    fontWeight: "700",
    letterSpacing: 0.75,
    color: "#1B1116"
  },
  subtitle: {
    fontSize: 11.5,
    fontWeight: "700",
    letterSpacing: 0.75,
    color: "#181A1F"
  },
  text: {
    fontSize: 13,
    fontWeight: "400",
    lineHeight: 19.5,
    color: "#1B1116"
  },
  more: {
    fontSize: 13,
    fontWeight: "600",
    lineHeight: 19.5,
    color: "#1C58F2"
  }
});
