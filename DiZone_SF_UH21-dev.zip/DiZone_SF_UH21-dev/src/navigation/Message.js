import React from "react";
import { StyleSheet, Text, View } from "react-native";
import { createStackNavigator } from "@react-navigation/stack";
import { Message } from "@/pages";
import chat from "@/pages/Message/chat";

const Stack = createStackNavigator();

const MessageStack = () => {
  return (
    <Stack.Navigator>
      <Stack.Screen name="MessageList" component={Message} />
      <Stack.Screen name="Chat" component={chat} />
    </Stack.Navigator>
  );
};

export default MessageStack;

const styles = StyleSheet.create({});
