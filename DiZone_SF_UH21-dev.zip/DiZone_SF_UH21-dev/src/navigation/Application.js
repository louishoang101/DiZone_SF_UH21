import "react-native-gesture-handler";
import React from "react";
import { View, Text } from "react-native";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import { Message, Search, Swipe } from "@/pages";
import { MessageIcon, ProfileIcon, SearchIcon, ShapeIcon } from "@/assets/svg";
import ProfileStack from "./Profile";
import MessageStack from "./Message";
import BookMeetingStack from "./BookMeeting";

const Tab = createBottomTabNavigator();

const Application = () => {
  return (
    <Tab.Navigator
      tabBarOptions={{
        style: { paddingVertical: 10, height: 70 }
      }}
      sceneContainerStyle={{
        backgroundColor: "#FFF"
      }}
      screenOptions={({ route }) => ({
        tabBarIcon: ({ focused, color, size }) => {
          let icon = {
            "Swipe": <SearchIcon focused={focused} />,
            "Message": <MessageIcon focused={focused} />,
            "BookMeeting": <ShapeIcon focused={focused} />,
            "Profile": <ProfileIcon focused={focused} />
          }[route.name];
          return icon;
        },
        title: ""
      })}>
      <Tab.Screen name="Swipe" component={Swipe} />
      <Tab.Screen name="Message" component={MessageStack} />
      <Tab.Screen name="BookMeeting" component={BookMeetingStack} />
      <Tab.Screen name="Profile" component={ProfileStack} />
    </Tab.Navigator>
  );
};

export default Application;
