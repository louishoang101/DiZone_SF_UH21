import React, { useEffect } from "react";
import { createStackNavigator } from "@react-navigation/stack";

import { BookMeeting, CreateTask } from "@/pages";

const Stack = createStackNavigator();

function BookMeetingStack() {
  return (
    <Stack.Navigator {...nativeStackConfig}>
      <Stack.Screen component={BookMeeting} name={Routes.BOOKMEETING} />
      <Stack.Screen component={CreateTask} name={Routes.CREATE_TASK} />
    </Stack.Navigator>
  );
}

export default React.memo(BookMeetingStack);
const nativeStackConfig = {
  mode: "modal",
  cardStyle: {
    backgroundColor: "transparent"
  },
  screenOptions: {
    gestureEnabled: true,
    headerShown: false,
    contentStyle: {
      backgroundColor: "transparent"
    },
    showDragIndicator: false,
    springDamping: 0.8,
    stackPresentation: "modal",
    transitionDuration: 0.35
  }
};
const Routes = {
  BOOKMEETING: "BookMeeting",
  CREATE_TASK: "CreateTask"
};
