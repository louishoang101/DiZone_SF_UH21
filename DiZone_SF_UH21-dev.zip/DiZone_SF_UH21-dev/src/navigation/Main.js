import "react-native-gesture-handler";
import React from "react";
import { View, Text } from "react-native";
import { NavigationContainer } from "@react-navigation/native";
import { createStackNavigator } from "@react-navigation/stack";
import Application from "./Application";
import { Roles } from "@/pages";
import { Theme } from "./Theme";

const Stack = createStackNavigator();

const MainScreen = () => {
  return (
    <NavigationContainer theme={Theme}>
      <Stack.Navigator>
        <Stack.Screen options={{ headerShown: false }} name="Roles" component={Roles} />
        <Stack.Screen options={{ headerShown: false }} name="ApplicationScreen" component={Application} />
      </Stack.Navigator>
    </NavigationContainer>
  );
};

export default MainScreen;
