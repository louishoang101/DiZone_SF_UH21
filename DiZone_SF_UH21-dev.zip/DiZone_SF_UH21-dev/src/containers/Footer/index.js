import React from "react";
import { View } from "react-native";

import { RoundButton } from "@/components";
import { COLORS } from "@/utils/constants";
import { styles } from "./styles";

export default function Footer({ handleChoice }) {
  return (
    <View style={styles.container}>
      <RoundButton name="times" size={23} color={COLORS.nope} onPress={() => handleChoice(-1)} />
      <RoundButton name="heart" size={23} color={COLORS.connect} onPress={() => handleChoice(1)} />
    </View>
  );
}
