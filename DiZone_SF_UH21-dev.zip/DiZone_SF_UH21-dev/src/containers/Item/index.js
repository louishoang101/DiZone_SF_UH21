import { ArrowRightIcon } from "@/assets/svg";
import React from "react";
import { Pressable, StyleSheet, Text, View } from "react-native";

const index = ({ icon, title, onPress, disableArrow = true }) => {
  return (
    <Pressable onPress={onPress}>
      <View style={styles.container}>
        <View flexDirection="row" alignItems="center" marginVertical={20}>
          <View marginLeft={20}>{icon}</View>
          <Text>{title}</Text>
        </View>
        <View marginRight={18}>{disableArrow && <ArrowRightIcon />}</View>
      </View>
    </Pressable>
  );
};

export default index;

const styles = StyleSheet.create({
  container: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    borderBottomWidth: 0.5,
    borderBottomColor: "#E2E2E2"
  }
});
