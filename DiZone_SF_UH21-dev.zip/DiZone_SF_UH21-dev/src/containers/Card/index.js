import React, { useCallback, useRef } from "react";
import { LinearGradient } from "expo-linear-gradient";
import { Animated, Image, Pressable, Text, View } from "react-native";

import { Choice } from "@/components";
import { ACTION_OFFSET } from "@/utils/constants";

import { styles } from "./styles";

export default function Card({ name, company, onPress, source, isFirst, swipe, tiltSign, ...rest }) {
  const rotate = Animated.multiply(swipe.x, tiltSign).interpolate({
    inputRange: [-ACTION_OFFSET, 0, ACTION_OFFSET],
    outputRange: ["8deg", "0deg", "-8deg"]
  });

  const connectOpacity = swipe.x.interpolate({
    inputRange: [25, ACTION_OFFSET],
    outputRange: [0, 1],
    extrapolate: "clamp"
  });

  const nopeOpacity = swipe.x.interpolate({
    inputRange: [-ACTION_OFFSET, -25],
    outputRange: [1, 0],
    extrapolate: "clamp"
  });

  const animatedCardStyle = {
    transform: [...swipe.getTranslateTransform(), { rotate }]
  };

  const renderChoice = useCallback(() => {
    return (
      <>
        <Animated.View style={[styles.choiceContainer, styles.connectContainer, { opacity: connectOpacity }]}>
          <Choice type="connect" />
        </Animated.View>
        <Animated.View style={[styles.choiceContainer, styles.nopeContainer, { opacity: nopeOpacity }]}>
          <Choice type="nope" />
        </Animated.View>
      </>
    );
  }, [connectOpacity, nopeOpacity]);

  return (
    <Animated.View style={[styles.container, isFirst && animatedCardStyle]} {...rest}>
      <Pressable onPress={onPress}>
        <Image source={source} style={styles.image} />
        <LinearGradient colors={["transparent", "rgba(0,0,0,0.9)"]} style={styles.gradient} />
        <View style={styles.container_text}>
          <Text style={styles.name}>{name}</Text>
          <Text style={[styles.name, { fontSize: 28 }]}>{company}</Text>
        </View>
        {isFirst && renderChoice()}
      </Pressable>
    </Animated.View>
  );
}
