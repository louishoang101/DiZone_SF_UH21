const { Dimensions } = require("react-native");

const { width, height } = Dimensions.get("screen");

export const CARD = {
  WIDTH: width * 0.83,
  HEIGHT: (width * 0.83 * 4) / 3,
  BORDER_RADIUS: 20,
  OUT_OF_SCREEN: width + 0.5 * width
};

export const COLORS = {
  connect: "#00eda6",
  nope: "#ff006f"
};

export const ACTION_OFFSET = 100;
