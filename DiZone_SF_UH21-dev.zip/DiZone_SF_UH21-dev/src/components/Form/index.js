import { Fonts } from "@/navigation/Theme";
import React from "react";
import { StyleSheet, Text, TextInput, View } from "react-native";

export const Input = ({ title, defaultValue }) => {
  return (
    <View marginBottom={15}>
      <Text style={[Fonts.text, { color: "#898989" }]}>{title}</Text>
      <TextInput defaultValue={defaultValue} style={[input.form, Fonts.text, { color: "#2C2C2C" }]} />
    </View>
  );
};

const input = StyleSheet.create({
  form: {
    borderBottomWidth: 0.5,
    borderBottomColor: "#E2E2E2",
    paddingVertical: 10
  }
});
