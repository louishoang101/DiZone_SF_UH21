import { Fonts } from "@/navigation/Theme";
import React from "react";
import { StyleSheet, Text, View } from "react-native";

const index = ({ variant, children, style }) => {
  return (
    <Text
      style={[
        Fonts.text,
        {
          header: Fonts.header,
          title: Fonts.title,
          subtitle: Fonts.subtitle,
          more: Fonts.more
        }[variant],
        style
      ]}>
      {children}
    </Text>
  );
};

export default index;

const styles = StyleSheet.create({});
