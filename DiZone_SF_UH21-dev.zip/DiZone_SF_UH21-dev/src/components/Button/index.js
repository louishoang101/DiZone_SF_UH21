import { useTheme } from "@react-navigation/native";
import React from "react";
import { Dimensions, StyleSheet, Text, View } from "react-native";

const { width } = Dimensions.get("window");

const index = ({ iconLeft, iconRight, title, onPress }) => {
  const { colors } = useTheme();
  return (
    <View style={[styles.container, { backgroundColor: colors.primary }]}>
      <View style={styles.left}>{iconLeft && iconLeft}</View>
      <Text style={styles.title}>{title}</Text>
      <View style={styles.right}>{iconRight && iconRight}</View>
    </View>
  );
};

export default index;

const styles = StyleSheet.create({
  container: {
    flexDirection: "row",
    width: width * 0.7,
    height: width * 0.7 * 0.2,
    marginVertical: 20,
    borderRadius: 12,
    justifyContent: "center",
    alignItems: "center"
  },
  title: {
    color: "#fff",
    fontWeight: "700",
    fontSize: 15
  },
  left: {
    position: "absolute",
    left: 25
  },
  right: {
    position: "absolute",
    right: 25
  }
});
