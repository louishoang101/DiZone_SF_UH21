# Power-BI embeded in a React app

Discover how to use the Power BI component for React and leverage the Power BI embedded analytics Client APIs via [this video tutorial](https://www.youtube.com/watch?v=A5KFY5Jh1Uc)

## Run in dev environment


```bash
npm install
```
```bash
npm install powerbi-client-react
```


update **./App.js with proper values for
```
"accessToken": "",
"embedUrl": "",
"reportId": ""
```

## License

MIT


