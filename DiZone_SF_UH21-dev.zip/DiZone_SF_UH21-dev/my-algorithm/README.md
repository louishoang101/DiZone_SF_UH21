# DiZone_SF_UH21
DiZone - UAVS Hackatrix - Hackathon for start-ups 2021
DiZone is a group of 5 young opportunity seekers who are from different states & citites across Australia and Viet Nam. I, Nguyen Hoang, take care of the data and algorithms of this project, while the others are in charge of a wide range of fields such as Business Administration, Database Development, and UI/UX Design. 
UAVS Hackatrix is a competition for students who are doing either one of the degrees: Master's degree, Undergraduate degree, and High School diploma. There are nearly 80 teams participated in this competition. 
Our project is to build a social network for start-ups in Viet Nam. We want to let their ideas be spoken to the investors. An idea of creating an app that connects creative students together was born as we saw hundreds of world-changing projects have been refused and forgotten by so many reasons. The app works like Tinder, carries the mission of Facebook, is fun as Tiktok, but it is professional like LinkedIn still. 
UI/UX design. Interface 
Back-end, database management
Data Cleaning 
Natural Language Processing
Recommendation System 
Data Visualization
