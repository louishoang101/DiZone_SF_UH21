import React, { Component } from "react";
import { StatusBar } from "expo-status-bar";
import { Platform } from "react-native";
import { SafeAreaProvider } from "react-native-safe-area-context";
import * as Calendar from "expo-calendar";
import MainScreen from "@/navigation/Main";

// export default function App() {
//   return (
//     <>
//       <Application />
//       <StatusBar style="auto" />
//     </>
//   );
// }
class App extends Component {
  async componentDidMount() {
    await this._askForCalendarPermissions();
    await this._askForReminderPermissions();

    // StatusBar.pushStackEntry({
    //   animated: true,
    //   barStyle: "light-content"
    // });
  }

  _askForCalendarPermissions = async () => {
    const { status } = await Calendar.requestCalendarPermissionsAsync();
    if (status === "granted") {
      const calendars = await Calendar.getCalendarsAsync(Calendar.EntityTypes.EVENT);
      console.log("Here are all your calendars:");
      console.log({ calendars });
    }
  };

  _askForReminderPermissions = async () => {
    if (Platform.OS === "android") {
      return true;
    }

    const { status } = await Calendar.requestRemindersPermissionsAsync();
    if (status === "granted") {
      const calendars = await Calendar.getRemindersPermissionsAsync(Calendar.EntityTypes.REMINDER);
      console.log("Here are all your calendars:");
      console.log({ calendars });
    }
  };

  render = () => (
    // <SafeAreaProvider style={{ backgroundColor: "#FFFFFF" }}>
    <>
      <MainScreen />
      <StatusBar style="auto" />
    </>
    // </SafeAreaProvider>
  );
}

export default App;
